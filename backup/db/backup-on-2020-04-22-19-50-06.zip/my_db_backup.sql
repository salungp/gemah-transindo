#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `role` int(11) NOT NULL,
  `password` varchar(256) NOT NULL,
  `profile_picture` varchar(256) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id`, `username`, `role`, `password`, `profile_picture`, `created_at`, `updated_at`) VALUES (1, 'root', 1, '$2y$10$HV76XQf1BWQSNShpuzm/eeuTFjgdDzyc9MT4EAdKUtT4wyPb07tta', '', '2020-04-21 15:44:46', '2020-04-22 22:31:51');
INSERT INTO `user` (`id`, `username`, `role`, `password`, `profile_picture`, `created_at`, `updated_at`) VALUES (2, 'editor', 2, '$2y$10$Yj1no6HRBDJeWC82.j9zXO7U3Jnkm17xmjuIPoDL5UCi112azlAza', '', '2020-04-21 22:51:05', '2020-04-21 23:02:19');


#
# TABLE STRUCTURE FOR: user_role
#

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `description` text NOT NULL,
  `theme` varchar(128) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user_role` (`id`, `title`, `description`, `theme`, `created_at`, `updated_at`) VALUES (1, 'admin', 'Super administrator.', 'primary', '2020-04-21 15:45:15', '2020-04-21 23:03:31');
INSERT INTO `user_role` (`id`, `title`, `description`, `theme`, `created_at`, `updated_at`) VALUES (2, 'editor', 'Hampir semua fitur dapat digunakan editor.', 'warning', '2020-04-21 22:18:19', '2020-04-21 23:03:47');


